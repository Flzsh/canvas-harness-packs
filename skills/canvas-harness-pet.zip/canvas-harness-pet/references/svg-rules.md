# The file format Canvas Harness accepts

Canvas Harness shows uploaded artwork as an **isolated image**: the SVG is validated, stored, and rendered through an
`<img>` (a data URL). It is never injected into the page. Three consequences drive everything below:

1. **Nothing from the page reaches the drawing.** No page fonts, no CSS variables, no `currentColor`, no course colour,
   no theme. Every colour is written into the file.
2. **No scripts and no outside resources.** Only self-contained CSS (`<style>`, `@keyframes`) and SMIL can animate.
3. **A static copy is made automatically** for people who use reduced motion or switch animation off: every animation
   is stripped and what remains is shown. So the drawing with all animation removed must be the complete picture
   (see "The rest pose" in `animation.md`).

Checked against Canvas Harness 3.9.3 and 4.0 Preview 6 (`extension/custom-art.js`, the same file in both).
`scripts/check.cjs` runs that same validator.

## The three slots

| Slot | Recommended `viewBox` | How it is shown | Notes |
|---|---|---|---|
| **Banner** (with the lettered title inside it) | `0 0 1680 240` | A strip of its own across the top of the course heading, up to 80, 140 (default) or 220 px tall for the banner sizes Small, Medium and Tall. From a pack the fit is **contain, aligned right** unless the pack sets `fit` and `position`. A banner uploaded or pasted on its own is framed to fill and shown still. | Transparent background. See `slots.md` for the safe areas. |
| **Icon** | `0 0 100 100` | 40 x 40 px in the bottom-left corner of the course row, 22 x 22 px beside the course name elsewhere, about 46 px in the course dock. | Must read at 22 px. |
| **Frame** (stored as the border) | `0 0 360 110` | Stretched over the whole course row (`preserveAspectRatio="none"`); the row's icon and text sit on top of it. A row is typically about 240 x 87 px. | Hollow and transparent in the middle: art only on the edges and corners. |

"All courses" (the overview) has its own banner, icon and frame slots; treat it as one more course.

Several pieces travel to the extension as one quick upload pack: plain text with a `<?ch-art ...?>` line before each
SVG (see `quick-upload.md`). Everything in this file applies to each SVG inside a pack exactly as it does to a file
uploaded on its own; a pack does not relax any rule.

## Hard limits

- 256 KiB per file (raw and after normalising); 2 MiB for all of a user's SVG artwork together. Aim far lower:
  banner <= 70 KB, icon <= 6 KB, frame <= 14 KB.
- At most 4,096 elements, nesting at most 64 deep, at most 60 attributes on one element.
- One `d` attribute holds at most 8,192 numbers and letters. Split very long paths.
- Each `<style>` (and each `style` attribute) at most 64 KiB of CSS; at most 16 `<style>` elements.
- Filters: `stdDeviation` at most 64, `numOctaves` at most 5, `baseFrequency` from 0 to 1.
- XML 1.0, UTF-8, one `<svg>` root. Give it `xmlns="http://www.w3.org/2000/svg"` (a missing one is added) and a
  `viewBox` (without one the picture cannot scale to its slot).

## Allowed elements

`svg g defs symbol use path rect circle ellipse line polyline polygon linearGradient radialGradient stop clipPath mask
pattern filter feGaussianBlur feOffset feBlend feComposite feColorMatrix feFlood feMerge feMergeNode feMorphology
feTurbulence feDisplacementMap feDropShadow title desc style text tspan textPath animate animateTransform animateMotion
set`

Not allowed (the upload is refused): `script`, `image`, `foreignObject`, `a`, `marker`, `switch`, `view`, nested `svg`,
anything with a namespace prefix (`inkscape:`, `sodipodi:`, `xlink:` other than `xlink:href`), `<!DOCTYPE>`, entities,
processing instructions.

Any of these is fine: the art can be as flat, painterly, geometric or detailed as the style wants. Two notes:
`text` shows in a fallback font (no page fonts reach the image), so draw lettering as paths when its look matters,
and filters cost a lot when animated.

## Allowed attributes

On every drawable element: `id class style transform opacity fill fill-rule fill-opacity stroke stroke-opacity
stroke-width stroke-linecap stroke-linejoin stroke-miterlimit stroke-dasharray stroke-dashoffset color visibility
display filter clip-path clip-rule mask vector-effect paint-order shape-rendering color-interpolation
color-interpolation-filters overflow pointer-events` plus the element's own geometry (`d`, `pathLength`, `x`, `y`,
`width`, `height`, `rx`, `ry`, `cx`, `cy`, `r`, `x1`..`y2`, `points`) and the usual attributes of gradients, stops,
patterns, filters and text (`offset`, `stdDeviation`, `font-size`...). Animation elements take only an `id` and their
own timing and value attributes (no `class` or `style`).

**Any other attribute is refused**, including every `data-*` attribute, `aria-*`, `role`, `tabindex`, `xml:id` and
event handlers (`onclick`...). Class names are letters, digits, `_` and `-`, starting with a letter or `_`.
Ids start with a letter or `_`. `href` may only be a local `#id`.

## Allowed CSS

- Rules, `@media`, `@keyframes` (and `@-webkit-keyframes`). No `@import`, `@font-face`, `@supports`, no nested rules.
- Selectors: type, `.class`, `#id`, `*`, `:nth-child()`-style pseudo-classes, attribute selectors, `> + ~`.
- Properties: `fill fill-rule fill-opacity stroke stroke-width stroke-opacity stroke-linecap stroke-linejoin
  stroke-dasharray stroke-dashoffset color stop-color stop-opacity opacity transform transform-origin transform-box
  filter clip-path mask display visibility paint-order shape-rendering vector-effect overflow pointer-events`,
  the `font-*`/`text-anchor`/`letter-spacing` group, `animation` and all `animation-*`, `transition` and all
  `transition-*` (and their `-webkit-` forms).
- **Refused:** `var()`, `attr()`, any `url()` that is not `url(#localId)`, and every property not in the list above:
  `offset-path`, `d` (no CSS path morphing), `mix-blend-mode`, `will-change`, `isolation`, `cursor`...
  Values may not contain `@`, a backslash, `/*`, or the characters `{ } < > ;`.
- `calc()`, `rotate()`, `translate()`, `scale()`, `cubic-bezier()`, `steps()`, `rgb()`, `hsl()` are fine.
- **A CSS rule beats a presentation attribute.** If a class sets `stroke`, a `stroke="..."` attribute on the same
  element is ignored. Give differently coloured strokes their own class. (`scripts/check.cjs` warns about this.)

## Allowed SMIL

- `animate` may target only: `x y cx cy r rx ry width height x1 x2 y1 y2 opacity fill stroke fill-opacity
  stroke-opacity stroke-width stroke-dashoffset stop-color stop-opacity`.
  **`d` cannot be animated**: there is no path morphing in this format. Movement comes from transforms, travel along a
  path, drawing-on, and switching between drawn poses (see `animation.md`).
- `animateTransform` (types `translate scale rotate skewX skewY`), `animateMotion` (with `path`, `rotate`,
  `keyPoints`), `set`.
- Clock values are plain times with a unit: `begin="2.5s"`, `dur="12s"` (a bare `dur="12"` is refused),
  `repeatCount="indefinite"`. Event and sync-base values (`begin="click"`, `begin="a.end"`) are refused.
- `calcMode` `linear | discrete | paced | spline`; `fill` `freeze | remove`.

## What gets a file refused most often

| Message (after "SVG artwork:") | Cause | Fix |
|---|---|---|
| "Unsupported SVG attribute data-..." | exporter or rig metadata | delete every `data-*`, `aria-*`, `role` |
| "Unsupported or unsafe SVG element <image>/<marker>/<foreignObject>" | embedded bitmap, arrowhead markers, HTML text | redraw as paths |
| "SVG XML namespaces and rebased resources are unsupported: xmlns:inkscape" | Inkscape/Illustrator export | export "plain SVG", strip `inkscape:`/`sodipodi:` |
| "Unsafe CSS function" | `var(--x)` | write the value out |
| "Unsafe SVG animation attributeName d" | path morph | use transforms or pose switching |
| "Unsupported SVG animation clock" | `begin="x.end"` | use absolute times and one shared cycle length |
| "Unsupported SVG CSS property" | `offset-path`, `mix-blend-mode`, `will-change`... | remove |
| "SVG file exceeds the 256 KiB upload limit" | too many points | fewer, longer paths; one decimal place |

## Writing compact paths

One decimal place is enough at these sizes. Prefer one absolute `M` followed by relative `c`/`q`/`l` segments. Put
strokes that share weight and colour in one `path` with several `M` sub-paths. Whitespace and XML comments are
allowed but count toward the size; ship without comments.

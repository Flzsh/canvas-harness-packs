# Colours

Six colours per mode carry the whole page:

| Key | Used for |
|---|---|
| `bg` | the page itself, where the background picture is thin or absent |
| `surface` | panels, cards, menus, the course list: where people read |
| `ink` | text and the main lines |
| `muted` | secondary text: dates, counts, hints |
| `line` | dividers and quiet outlines |
| `accent` | links, the selected tab, highlights, buttons, switches |

## Rules the checker enforces (WCAG contrast)
- `ink` on `bg`: at least 4.5:1. `ink` on `surface`: at least 4.5:1.
- `muted` on `surface`: at least 3:1.
- `accent` on `surface`: at least 3:1 (it marks links and selected things).
- Not checked, but needed: Home's modules have no fill of their own, so their text sits on `bg` as well. Give `muted`
  and `accent` 3:1 on `bg` too (4.5:1 is better for link-sized text). Canvas Harness's own red for late and missing
  work (#A62639 light, #F08C7E dark) is drawn on `bg`: a mid-grey light `bg` such as #B3B3B8 gives it only 3.4:1;
  keep a light `bg` at about #CFCFD4 or lighter (or go dark).
- Light mode: `surface` is the lightest or near it; dark mode: the darkest or near it. (Not enforced, but a theme that
  flips this looks broken beside Canvas's own pages.)

Contrast is `(L1 + 0.05) / (L2 + 0.05)` of relative luminances; the checker names each pair that fails, with its ratio
and the ratio it needs (`$.colors.light.muted: contrast on $.colors.light.surface is 2.07:1; requires 3:1`).

## Passing the rules in any style
- Pastel or soft looks: keep the pastels for `bg`, `line`, frames and art; make `ink` a deep version of your main hue
  (not grey) and `muted` a mid version.
- Neon on dark: neon for `accent` and art; `ink` near white tinted with the theme hue; `surface` a deep, desaturated
  version of the background.
- Monochrome: vary lightness only; check `muted` carefully, it fails most often.
- Two modes from one idea: keep the hues, swap lightness, and lower saturation in dark mode (saturated colours glow
  on dark surfaces).
